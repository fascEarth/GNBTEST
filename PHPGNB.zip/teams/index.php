<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/teams/style.css">
  <title>Team Management</title>
</head>
<body>
  <div class="container">
    <h2>Teams List</h2>
    <table id="teamsTable">
      <!-- Table rows will be populated using JavaScript -->
    </table>
    <button onclick="openModal('add')">Add Team</button>

    <!-- Edit/Add Team Modal -->
    <div id="myModal" class="modal">
      <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <form id="teamForm" onsubmit="saveTeam(); return false;">
          <input type="hidden" id="teamType">
          <input type="hidden" id="teamId" name="teamId">
          <label for="teamName">Team Name:</label>
          <input type="text" id="teamName" name="teamName" required>
          <button type="submit">Save</button>
        </form>
      </div>
    </div>

    <script src="/teams/script.js"></script>
  </div>
</body>
</html>
