document.addEventListener('DOMContentLoaded', function () {
  loadTeams();
});

let teamsLength = 0;

function loadTeams() {
  fetch('/teams/teams.php')
    .then(response => response.json())
    .then(data => {
      teamsLength = data.length;
      const table = document.getElementById('teamsTable');
      table.innerHTML = '<tr><th>Team Name</th><th>Action</th></tr>';

      data.forEach(team => {
        const row = table.insertRow();
        row.innerHTML = `<td>${team.teamName}</td>
                          <td><button onclick="openModal('edit', '${team.teamId}')">Edit</button>
                          <button onclick="deleteTeam('${team.teamId}','${team.teamName}')">Delete</button></td>`;
      });
    })
    .catch(error => console.error('Error fetching teams:', error));
}

function openModal(mode, teamId = '') {
  const modal = document.getElementById('myModal');
  modal.style.display = 'block';

  const form = document.getElementById('teamForm');
  form.reset();
  document.getElementById('teamType').value = mode;

  if (mode === 'edit') {
    fetch(`/teams/teams.php?teamId=${teamId}`)
      .then(response => response.json())
      .then(teamData => {
        document.getElementById('teamId').value = teamData.teamId;
        document.getElementById('teamName').value = teamData.teamName;
      })
      .catch(error => console.error('Error fetching team data:', error));
  }
}

function closeModal() {
  document.getElementById('myModal').style.display = 'none';
}

function saveTeam() {
  const form = document.getElementById('teamForm');
  const formData = new FormData(form);
  const teamName = formData.get('teamName');

  const isEdit = document.getElementById('teamType').value == 'edit' ? true : false;
  const teamId = isEdit ? formData.get('teamId') : teamsLength + 1;

  if (!isEdit) {
    formData.append('teamId', teamId);
  }

  const formDataObject = {};
  formData.forEach((value, key) => {
    formDataObject[key] = value;
  });

  const requestOptions = {
    method: isEdit ? 'PUT' : 'POST',
    body: isEdit ? JSON.stringify(formDataObject) : formData,
  };

  fetch(`/teams/teams.php${isEdit ? `?teamId=${teamId}` : ''}`, requestOptions)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        closeModal();
        loadTeams();
      } else {
        alert(`Error ${isEdit ? 'updating' : 'saving'} team. Please try again.`);
      }
    })
    .catch(error => console.error(`Error ${isEdit ? 'updating' : 'saving'} team:`, error));
}

function deleteTeam(teamId, teamName) {
  const confirmDelete = confirm(`Are you sure you want to delete the team '${teamName}'?`);

  if (confirmDelete) {
    fetch(`/teams/teams.php?teamId=${teamId}`, {
      method: 'DELETE',
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          loadTeams();
        } else {
          alert('Error deleting team. Please try again.');
        }
      })
      .catch(error => console.error('Error deleting team:', error));
  }
}
