<?php

$filename = 'teams.txt';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $teams = [];

    if (file_exists($filename)) {
        $teamsData = file_get_contents($filename);
        $teams = json_decode($teamsData, true);
    }

    $teamIdParam = $_GET['teamId'] ?? null;

    if ($teamIdParam !== null) {
        $foundTeam = null;
        foreach ($teams as $team) {
            if ($team['teamId'] === $teamIdParam) {
                $foundTeam = $team;
                break;
            }
        }

        echo json_encode($foundTeam ?? ['error' => 'Team not found']);
    } else {
        echo json_encode($teams);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teamId = $_POST['teamId'];
    $teamName = $_POST['teamName'];

    $newTeam = [
        'teamId' => $teamId,
        'teamName' => $teamName,
    ];

    $teams = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
    $teams[] = $newTeam;

    $updatedData = json_encode($teams, JSON_PRETTY_PRINT);
    file_put_contents($filename, $updatedData);

    echo json_encode(['success' => true]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $teamId = $_GET['teamId'] ?? null;

    $teams = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];

    $indexToDelete = array_search($teamId, array_column($teams, 'teamId'));

    if ($indexToDelete !== false) {
        array_splice($teams, $indexToDelete, 1);
        $updatedData = json_encode($teams, JSON_PRETTY_PRINT);
        file_put_contents($filename, $updatedData);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $rawData = file_get_contents("php://input");
    $putData = json_decode($rawData, true);

    $teamId = $putData['teamId'] ?? null;
    $teamName = $putData['teamName'];

    $teams = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];

    $indexToEdit = array_search($teamId, array_column($teams, 'teamId'));

    if ($indexToEdit !== false) {
        $teams[$indexToEdit]['teamName'] = $teamName;

        $updatedData = json_encode($teams, JSON_PRETTY_PRINT);
        file_put_contents($filename, $updatedData);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}


?>