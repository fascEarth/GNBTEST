document.addEventListener('DOMContentLoaded', () => loadWeeks());
let weeksLength = 0;

const loadWeeks = () => fetch('/weeks/weeks.php')
  .then(response => response.json())
  .then(data => {
    weeksLength = data ? data.length : 0;
    const table = document.getElementById('weeksTable');
    table.innerHTML = '<tr><th>Week Name</th><th>From Date</th><th>To Date</th><th>Action</th></tr>';
    data.forEach(week => {
      const row = table.insertRow();
      row.innerHTML = `<td>${week.weekName}</td><td>${week.fromDate}</td><td>${week.toDate}</td>
                        <td><button onclick="openModal('edit', '${week.weekId}')">Edit</button>
                        <button onclick="deleteWeek('${week.weekId}','${week.weekName}')">Delete</button></td>`;
    });
  })
  .catch(error => console.error('Error fetching weeks:', error));

const openModal = (mode, weekId = '') => {
  const modal = document.getElementById('myModal');
  modal.style.display = 'block';
  const form = document.getElementById('weekForm');
  form.reset();
  document.getElementById('weekType').value = mode;

  if (mode === 'edit') {
    fetch(`/weeks/weeks.php?weekId=${weekId}`)
      .then(response => response.json())
      .then(weekData => {
        document.getElementById('weekId').value = weekData.weekId;
        document.getElementById('weekName').value = weekData.weekName;
        document.getElementById('fromDate').value = weekData.fromDate;
        document.getElementById('toDate').value = weekData.toDate;
      })
      .catch(error => console.error('Error fetching week data:', error));
  }
};

const closeModal = () => document.getElementById('myModal').style.display = 'none';

const saveWeek = async () => {
  const form = document.getElementById('weekForm');
  const formData = new FormData(form);
  const isEdit = document.getElementById('weekType').value === 'edit';
  const weekId = isEdit ? formData.get('weekId') : weeksLength + 1;
  if (!isEdit) formData.append('weekId', weekId);

  const formDataObject = Object.fromEntries(formData.entries());
  const requestOptions = {
    method: isEdit ? 'PUT' : 'POST',
    body: isEdit ? JSON.stringify(formDataObject) : formData,
  };

  try {
    const response = await fetch(`/weeks/weeks.php${isEdit ? `?weekId=${weekId}` : ''}`, requestOptions);
    const data = await response.json();

    if (data.success) {
      closeModal();
      loadWeeks();
    } else {
      alert(`Error ${isEdit ? 'updating' : 'saving'} week. Please try again.`);
    }
  } catch (error) {
    console.error(`Error ${isEdit ? 'updating' : 'saving'} week:`, error);
  }
};

const deleteWeek = async (weekId, weekName) => {
  const confirmDelete = confirm(`Are you sure you want to delete the week '${weekName}'?`);

  if (confirmDelete) {
    try {
      const response = await fetch(`/weeks/weeks.php?weekId=${weekId}`, { method: 'DELETE' });
      const data = await response.json();

      if (data.success) {
        loadWeeks();
      } else {
        alert('Error deleting week. Please try again.');
      }
    } catch (error) {
      console.error('Error deleting week:', error);
    }
  }
};
