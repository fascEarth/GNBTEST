<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/weeks/style.css">
  <title>Weeks Management</title>
</head>
<body>
  <div class="container">
    <h2>Weeks List</h2>
    <table id="weeksTable"></table>
    <button onclick="openModal('add')">Add Week</button>

    <div id="myModal" class="modal">
      <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <form id="weekForm" onsubmit="saveWeek(); return false;" enctype="multipart/form-data">
          <input type="hidden" id="weekType">
          <input type="hidden" id="weekId" name="weekId">
          <label for="weekName">Week Name:</label>
          <input type="text" id="weekName" name="weekName" required>
          <label for="fromDate">From Date:</label>
          <input type="date" id="fromDate" name="fromDate" required>
          <label for="toDate">To Date:</label>
          <input type="date" id="toDate" name="toDate" required>
          <button type="submit">Save</button>
        </form>
      </div>
    </div>

    <script src="/weeks/script.js"></script>
  </div>
</body>
</html>
