<?php

$filename = 'weeks.txt';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $weeks = [];

    if (file_exists($filename)) {
        $weeksData = file_get_contents($filename);
        $weeks = json_decode($weeksData, true);
    }

    $weekIdParam = $_GET['weekId'] ?? null;

    if ($weekIdParam !== null) {
        $foundWeek = null;
        foreach ($weeks as $week) {
            if ($week['weekId'] === $weekIdParam) {
                $foundWeek = $week;
                break;
            }
        }

        echo json_encode($foundWeek ?? ['error' => 'Week not found']);
    } else {
        echo json_encode($weeks);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $weekId = $_POST['weekId'];
    $weekName = $_POST['weekName'];
    $fromDate = $_POST['fromDate'];
    $toDate = $_POST['toDate'];

    $newWeek = [
        'weekId' => $weekId,
        'weekName' => $weekName,
        'fromDate' => $fromDate,
        'toDate' => $toDate
    ];

    $weeks = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
    $weeks[] = $newWeek;

    $updatedData = json_encode($weeks, JSON_PRETTY_PRINT);
    file_put_contents($filename, $updatedData);

    echo json_encode(['success' => true]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $weekId = $_GET['weekId'] ?? null;

    $weeks = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];

    $indexToDelete = array_search($weekId, array_column($weeks, 'weekId'));

    if ($indexToDelete !== false) {
        array_splice($weeks, $indexToDelete, 1);
        $updatedData = json_encode($weeks, JSON_PRETTY_PRINT);
        file_put_contents($filename, $updatedData);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $rawData = file_get_contents("php://input");
    $putData = json_decode($rawData, true);

    $weekId = $putData['weekId'] ?? null;
    $weekName = $putData['weekName'];
    $fromDate = $putData['fromDate'];
    $toDate = $putData['toDate'];

    $weeks = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];

    $indexToEdit = array_search($weekId, array_column($weeks, 'weekId'));

    if ($indexToEdit !== false) {
        $weeks[$indexToEdit]['fromDate'] = $fromDate;
        $weeks[$indexToEdit]['toDate'] = $toDate;

        $updatedData = json_encode($weeks, JSON_PRETTY_PRINT);
        file_put_contents($filename, $updatedData);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}
