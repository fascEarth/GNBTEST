$(document).ready(function () {
  loadWeeks();

  function loadWeeks() {
    $.ajax({
      url: '/weeks/weeks.txt',
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        const weekDropdown = $('#weekDropdown');

        data.forEach(week => {
          const option = $('<option></option>');
          option.val(week.weekId);
          option.text(`${week.weekName} (${week.fromDate} - ${week.toDate})`);
          weekDropdown.append(option);
        });

        // Load calendar data for the first week by default
        loadCalendarData(data, data[0].weekId);

        // Trigger data loading when a week is selected
        weekDropdown.on('change', function () {
          const selectedWeek = weekDropdown.val();
          loadCalendarData(data, selectedWeek);
        });
      },
      error: function (error) {
        console.error('Error fetching weeks:', error);
      }
    });
  }

  function updateRowTotal(row, id, unixTimestamp, teamId) {
    const inputs = row.find('.hour-input' + id);
    let rowTotal = 0;

    inputs.each(function () {
      const hours = parseFloat($(this).val()) || 0;
      rowTotal += hours;
    });

    const totalInput = row.find('.total-input' + id);
    totalInput.val(formatHours(rowTotal));

    let sum = 0;
    $('.timestamp-input_' + unixTimestamp + '_' + teamId).each(function () {

      if (parseFloat($(this).val()) > 0) {
        sum += parseFloat($(this).val());
      }
    });

    $('.show-timestamp-input_' + unixTimestamp + '_' + teamId).val(sum);

    let hsum = 0;
    $('.head-tst' + teamId).each(function () {

      if (parseFloat($(this).val()) > 0) {
        hsum += parseFloat($(this).val());
      }
    });

    $('.show-head-tst' + teamId).val(hsum);


    let lsum = 0;
    $('.list_' + unixTimestamp).each(function () {

      if (parseFloat($(this).val()) > 0) {
        lsum += parseFloat($(this).val());
      }
    });

    $('.show-timestamp-input_' + unixTimestamp+'_total').val(lsum);


    let clsum = 0;
    $('.commonTotalSp').each(function () {

      if (parseFloat($(this).val()) > 0) {
          clsum += parseFloat($(this).val());
      }
    });

    $('.total-input-total').val(clsum);


   
    
    
  }

  function getDaysBetweenDates(startDate, endDate) {
    const days = [];
    const currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      days.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return days;
  }

  function formatHours(hours) {
    const formattedHours = Math.floor(hours);
    const minutes = Math.round((hours - formattedHours) * 60);
    return `${formattedHours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  }

  function loadCalendarData(data, selectedWeek) {
    $.when(
      $.ajax({ url: '/teams/teams.txt', method: 'GET', dataType: 'json' }),
      $.ajax({ url: '/employee/employees.txt', method: 'GET', dataType: 'json' })
    ).done(function (teamsResponse, employeesResponse) {
      const teams = teamsResponse[0];
      const employees = employeesResponse[0];

      // Clear existing data
      $('#topHeader').empty();
      $('#calendarBody').empty();

      // Get the selected week's start and end dates
      const selectedWeekData = data.find(week => week.weekId === selectedWeek);
      const startDate = new Date(selectedWeekData.fromDate);
      const endDate = new Date(selectedWeekData.toDate);

      // Get the list of days for the selected week
      const daysOfWeek = getDaysBetweenDates(startDate, endDate);

      // Populate top header
      const topHeader = $('#topHeader');
      const headerRow = $('<tr></tr>');
      const daysHeader = $('<th></th>').text('#');
      topHeader.append(daysHeader);

      daysOfWeek.forEach(day => {
        const th = $('<th></th>').text(day.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'short' }));
        topHeader.append(th);
      });

      const totalHeader = $('<th></th>').text('Total');
      topHeader.append(totalHeader);

      // Populate calendar body
      const calendarBody = $('#calendarBody');

      // Function to populate team data
      function populateTeam(teamData) {
        // Row for team name
        const teamNameRow = $('<tr></tr>');
        const teamNameCell = $('<td></td>').text(teamData.teamName);
        teamNameRow.append(teamNameCell);

        // Cell for each day
        daysOfWeek.forEach(day => {

          const date = new Date(day);
          const unixTimestamp = date.getTime() / 1000;

          const td = $('<td></td>');
          const input = $('<input>').attr('type', 'text').addClass('form-control list_'+unixTimestamp+' head-tst' + teamData.teamId + ' show-timestamp-input_' + unixTimestamp + '_' + teamData.teamId).prop('disabled', true);
          input.on('input', function () {
            updateRowTotal(teamNameRow);
          });
          td.append(input);
          teamNameRow.append(td);
        });

        // Total cell with input box
        const totalCell = $('<td></td>');
        const totalInput = $('<input>').attr('type', 'text').addClass('form-control commonTotalSp show-head-tst' + teamData.teamId + ' total-input').prop('disabled', true);
        totalCell.append(totalInput);
        teamNameRow.append(totalCell);

        calendarBody.append(teamNameRow);

        // Iterate over team members
        const teamEmployees = employees.filter(employee => employee.teamId === teamData.teamId);
        teamEmployees.forEach(employee => {
          const employeeRow = $('<tr></tr>');
          const employeeNameCell = $('<td></td>').text(employee.employeeName);
          employeeRow.append(employeeNameCell);

          // Cell for each day
          daysOfWeek.forEach(day => {
            const date = new Date(day);
            const unixTimestamp = date.getTime() / 1000;
            const td = $('<td></td>');
            const input = $('<input>').attr('type', 'time').addClass('form-control  hour-input' + employee.employeeId + ' timestamp-input_' + unixTimestamp + '_' + teamData.teamId);
            input.on('input', function () {
              updateRowTotal(employeeRow, employee.employeeId, unixTimestamp, teamData.teamId);
            });
            td.append(input);
            employeeRow.append(td);
          });

          // Total cell with input box
          const totalCell = $('<td></td>');
          const totalInput = $('<input>').attr('type', 'text').addClass('form-control total-input total-input' + employee.employeeId).prop('disabled', true);
          totalCell.append(totalInput);
          employeeRow.append(totalCell);

          calendarBody.append(employeeRow);
        });
      }

      // Populate data for each team
      teams.forEach(team => {
        populateTeam(team);
      });

      // Add Total row
      const totalRow = $('<tr></tr>');
      const totalCell = $('<td></td>').text('Total');
      totalRow.append(totalCell);

      daysOfWeek.forEach(day => {
        const date = new Date(day);
        const unixTimestamp = date.getTime() / 1000;
        const td = $('<td></td>');
        const input = $('<input>').attr('type', 'text').addClass('form-control show-timestamp-input_' + unixTimestamp + '_total').prop('disabled', true);
        td.append(input);
        totalRow.append(td);
      });

      const totalCellInput = $('<input>').attr('type', 'text').addClass('form-control show-head-tst_total total-input-total').prop('disabled', true);
      const totalCellTotal = $('<td></td>').append(totalCellInput);
      totalRow.append(totalCellTotal);

      calendarBody.append(totalRow);
    }).fail(function (error) {
      console.error('Error fetching data:', error);
    });
  }
});
