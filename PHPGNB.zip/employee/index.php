<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/employee/style.css">
  <title>Employee Management</title>
</head>
<body>
  <div class="container">
    <h2>Employees List</h2>
    <table id="employeesTable">
      <!-- Table rows will be populated using JavaScript -->
    </table>
    <button onclick="openModal('add')">Add Employee</button>

    <!-- Edit/Add Employee Modal -->
    <div id="myModal" class="modal">
      <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <form id="employeeForm" onsubmit="saveEmployee(); return false;">
          <input type="hidden" id="employeeType">
          <input type="hidden" id="employeeId" name="employeeId">
          <label for="employeeName">Employee Name:</label>
          <input type="text" id="employeeName" name="employeeName" required>
          <label for="team">Team:</label>
          <select id="team" name="team" required></select>
          <button type="submit">Save</button>
        </form>
      </div>
    </div>

    <script src="/employee/script.js"></script>
  </div>
</body>
</html>
