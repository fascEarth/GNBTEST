<?php

$filename = 'employees.txt';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $employees = [];

    if (file_exists($filename)) {
        $employeesData = file_get_contents($filename);
        $employees = json_decode($employeesData, true);
    }

    $employeeIdParam = $_GET['employeeId'] ?? null;

    if ($employeeIdParam !== null) {
        $foundEmployee = null;
        foreach ($employees as $employee) {
            if ($employee['employeeId'] === $employeeIdParam) {
                $foundEmployee = $employee;
                break;
            }
        }

        echo json_encode($foundEmployee ?? ['error' => 'Employee not found']);
    } else {
        echo json_encode($employees);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employeeId = $_POST['employeeId'];
    $employeeName = $_POST['employeeName'];
    $teamId = $_POST['team'];

    $newEmployee = [
        'employeeId' => $employeeId,
        'employeeName' => $employeeName,
        'teamId' => $teamId,
    ];

    $employees = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
    $employees[] = $newEmployee;

    $updatedData = json_encode($employees, JSON_PRETTY_PRINT);
    file_put_contents($filename, $updatedData);

    echo json_encode(['success' => true]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $employeeId = $_GET['employeeId'] ?? null;

    $employees = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];

    $indexToDelete = array_search($employeeId, array_column($employees, 'employeeId'));

    if ($indexToDelete !== false) {
        array_splice($employees, $indexToDelete, 1);
        $updatedData = json_encode($employees, JSON_PRETTY_PRINT);
        file_put_contents($filename, $updatedData);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $rawData = file_get_contents("php://input");
    $putData = json_decode($rawData, true);

    $employeeId = $putData['employeeId'] ?? null;
    $employeeName = $putData['employeeName'];
    $teamId = $putData['team'];

    $employees = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];

    $indexToEdit = array_search($employeeId, array_column($employees, 'employeeId'));

    if ($indexToEdit !== false) {
        $employees[$indexToEdit]['employeeName'] = $employeeName;
        $employees[$indexToEdit]['teamId'] = $teamId;

        $updatedData = json_encode($employees, JSON_PRETTY_PRINT);
        file_put_contents($filename, $updatedData);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>
