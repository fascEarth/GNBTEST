document.addEventListener('DOMContentLoaded', function () {
  loadEmployees();
  loadTeams();
});

let employeesLength = 0;

function loadEmployees() {
  fetch('/employee/employees.php')
    .then(response => response.json())
    .then(data => {
      employeesLength = data.length;
      const table = document.getElementById('employeesTable');
      table.innerHTML = '<tr><th>Employee Name</th><th>Team</th><th>Action</th></tr>';

      data.forEach(employee => {
        const row = table.insertRow();
        row.innerHTML = `<td>${employee.employeeName}</td><td>${employee.teamId}</td>
                          <td><button onclick="openModal('edit', '${employee.employeeId}')">Edit</button>
                          <button onclick="deleteEmployee('${employee.employeeId}','${employee.employeeName}')">Delete</button></td>`;
      });
    })
    .catch(error => console.error('Error fetching employees:', error));
}

function loadTeams() {
  fetch('../teams/teams.php')
    .then(response => response.json())
    .then(data => {
      const teamSelect = document.getElementById('team');
      teamSelect.innerHTML = '';

      data.forEach(team => {
        const option = document.createElement('option');
        option.value = team.teamId;
        option.textContent = team.teamName;
        teamSelect.appendChild(option);
      });
    })
    .catch(error => console.error('Error fetching teams:', error));
}

function openModal(mode, employeeId = '') {
  const modal = document.getElementById('myModal');
  modal.style.display = 'block';

  const form = document.getElementById('employeeForm');
  form.reset();
  document.getElementById('employeeType').value = mode;

  if (mode === 'edit') {
    fetch(`/employee/employees.php?employeeId=${employeeId}`)
      .then(response => response.json())
      .then(employeeData => {
        document.getElementById('employeeId').value = employeeData.employeeId;
        document.getElementById('employeeName').value = employeeData.employeeName;
        document.getElementById('team').value = employeeData.teamId;
      })
      .catch(error => console.error('Error fetching employee data:', error));
  }
}

function closeModal() {
  document.getElementById('myModal').style.display = 'none';
}

function saveEmployee() {
  const form = document.getElementById('employeeForm');
  const formData = new FormData(form);
  const employeeName = formData.get('employeeName');

  const isEdit = document.getElementById('employeeType').value == 'edit' ? true : false;
  const employeeId = isEdit ? formData.get('employeeId') : employeesLength + 1;

  if (!isEdit) {
    formData.append('employeeId', employeeId);
  }

  const formDataObject = {};
  formData.forEach((value, key) => {
    formDataObject[key] = value;
  });

  const requestOptions = {
    method: isEdit ? 'PUT' : 'POST',
    body: isEdit ? JSON.stringify(formDataObject) : formData,
  };

  fetch(`/employee/employees.php${isEdit ? `?employeeId=${employeeId}` : ''}`, requestOptions)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        closeModal();
        loadEmployees();
      } else {
        alert(`Error ${isEdit ? 'updating' : 'saving'} employee. Please try again.`);
      }
    })
    .catch(error => console.error(`Error ${isEdit ? 'updating' : 'saving'} employee:`, error));
}

function deleteEmployee(employeeId, employeeName) {
  const confirmDelete = confirm(`Are you sure you want to delete the employee '${employeeName}'?`);

  if (confirmDelete) {
    fetch(`/employee/employees.php?employeeId=${employeeId}`, {
      method: 'DELETE',
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          loadEmployees();
        } else {
          alert('Error deleting employee. Please try again.');
        }
      })
      .catch(error => console.error('Error deleting employee:', error));
  }
}
