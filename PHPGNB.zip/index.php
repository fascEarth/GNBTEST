<?php
// index.php

$requestedPath = isset($_GET['path']) ? $_GET['path'] : 'home';
$pagePath = __DIR__ . '/' . $requestedPath . '/index.php';

if (file_exists($pagePath)) {
    require $pagePath;
} else {
    echo "Page not found!";
}
?>
